<p align="center">
</center>
  <h1 align="center">wifi hacker</h1>
  <p align="center">Script ini digunakan untuk menyerang koneksi wifi, Mendukung Semua Efek (WEP, WPS, WPA, WPA2)<p>
<p align="center">
  <img src="https://img.shields.io/badge/Instagram-bubble.si-red"></center>
  
# Installation


Download file:``` https://github.com/h4ckDC6/wifi-hacker/ ```
```
$apt update
```
```
$apt upgrade
```
```
$pkg install git
```
```
$git clone https://github.com/h4ckDC6/wifi-hacker
```
```
$cd wifi-hacker
```
```
$chmod +x wifi-hacker.sh
```
```
$./wifi-hacker.sh
```
# guide
> gunakan shell terminal linux

**jika Anda menggunakan TERMUX maka Anda harus ```ROOT```terlebih dahulu**

> di era digital saat ini, internet telah meningkat menjadi salah satu kebutuhan dasar bagi masyarakat. Salah satu cara untuk mendapatkan koneksi internet yang cepat dan gratis tentunya adalah dengan menghubungkan ke jaringan WiFi.
Namun sayangnya, WiFi dengan internet kecepatan tinggi biasanya dibanderol dengan harga yang cukup mahal juga.
dan anda mungkin akan berfikir jika tidak memiliki jaringan internet opsi yang harus di pilih adalah menymbungkan koneksi ke internet wifi yang ada ,namun sayangnya itu memiliki sebuah keamanan yaitu _kata sandi_ yang harus di masukkan agar bisa terhubung.





